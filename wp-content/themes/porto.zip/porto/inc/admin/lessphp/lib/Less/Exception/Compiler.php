<?php

/**
 * Compiler Exception
 */
class Less_Exception_Compiler extends Less_Exception_Parser {

}
