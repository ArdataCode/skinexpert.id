<?php
/**
 * @private
 * @property mixed $value
 */
interface Less_Tree_HasValueProperty {

}
